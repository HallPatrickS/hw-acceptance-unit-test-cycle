FactoryGirl.define do
  factory :movie do
    title 'New Movie'
    rating 'R'
    description 'No description'
    release_date '12-12-2012'
  end
end
